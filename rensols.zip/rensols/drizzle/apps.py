from django.apps import AppConfig


class DrizzleConfig(AppConfig):
    name = 'drizzle'
