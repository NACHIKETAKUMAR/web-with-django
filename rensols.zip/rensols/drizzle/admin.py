from django.contrib import admin
from drizzle.models import customer

# Register your models here.
admin.site.register(customer)