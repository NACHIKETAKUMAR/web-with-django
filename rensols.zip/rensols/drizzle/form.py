from drizzle.models import customer
from django import forms
from drizzle.models import UserData
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
class customerForm(forms.ModelForm):
    class Meta:
        model=customer
        fields="__all__"
class UserForm(UserCreationForm):
    class Meta:
        model = User

        fields = ('username', 'first_name', 'last_name',
              'email', 'password1', 'password2')

class RegForm(forms.ModelForm):
     dob = forms.DateField(label='Date of Birth')
     choices = [('male', 'Male'),
                ('female', 'Female')]
     gender = forms.ChoiceField(choices=choices, widget=forms.RadioSelect)

     class Meta:
         model = UserData

         fields = ('bio', 'gender', 'dob', 'location')
class CustomerForm(forms.Form):
    cid=forms.IntegerField()
    cfname=forms.CharField(label='enter first name',max_length=30)
    clname = forms.CharField(label='enter last name', max_length=30)
    file=forms.FileField (widget=forms.ClearableFileInput(attrs={'multiple':True}))
